var class_pv_wnd =
[
    [ "PvWnd", "class_pv_wnd.html#a7269f0df82539541a96aae2cbfb02427", null ],
    [ "~PvWnd", "class_pv_wnd.html#a915b2b8bf32050b3aba43b5db21307a8", null ],
    [ "Close", "class_pv_wnd.html#a946728a22a001d8bae8ff00b3e27614e", null ],
    [ "Create", "class_pv_wnd.html#a6555e535a860dbcc46e46c316fd0c0be", null ],
    [ "GetPosition", "class_pv_wnd.html#add1180270698fd9e722839e7c2988679", null ],
    [ "GetTitle", "class_pv_wnd.html#a10db35ac908a34349bc8d1befcbd21f6", null ],
    [ "SetPosition", "class_pv_wnd.html#a141bdf82f5141568b850727475f3aa37", null ],
    [ "SetTitle", "class_pv_wnd.html#a0fb23fa232d193b2666d7682050c5008", null ]
];