var class_pv_gen_boolean =
[
    [ "PvGenBoolean", "class_pv_gen_boolean.html#a63cba9acb49744119f2bbb907a3dd33f", null ],
    [ "~PvGenBoolean", "class_pv_gen_boolean.html#abda229cb7c399edcc7def734fd8e0528", null ],
    [ "GetValue", "class_pv_gen_boolean.html#a45bf2f23192e9756be4187bb470c7e3a", null ],
    [ "SetValue", "class_pv_gen_boolean.html#a9965ebeba345218cde129be620cf4b38", null ]
];