var class_pv_u_s_b_host_controller =
[
    [ "PvUSBHostController", "class_pv_u_s_b_host_controller.html#a405f54218ad0a04dfa200a4d5551b1d2", null ],
    [ "~PvUSBHostController", "class_pv_u_s_b_host_controller.html#a5352993207b880cab0a12c1a8e9a56de", null ],
    [ "GetDeviceID", "class_pv_u_s_b_host_controller.html#a9e51b9101407528125d39f60eaa52a0e", null ],
    [ "GetRevision", "class_pv_u_s_b_host_controller.html#a19ad8a00765244adaa7db7099d6884ec", null ],
    [ "GetSpeed", "class_pv_u_s_b_host_controller.html#ab4c6503ff2eb45254651e8d6a80ad56c", null ],
    [ "GetSubsystemID", "class_pv_u_s_b_host_controller.html#a5367d6187919e16428450e26fb974c4e", null ],
    [ "GetVendorID", "class_pv_u_s_b_host_controller.html#a0a914585c183d59396fe23ff8d558eb8", null ]
];