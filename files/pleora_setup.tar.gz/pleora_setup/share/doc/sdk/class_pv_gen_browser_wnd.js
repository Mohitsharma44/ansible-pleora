var class_pv_gen_browser_wnd =
[
    [ "PvGenBrowserWnd", "class_pv_gen_browser_wnd.html#a99c26a424a59077efc47cc56c8b817d5", null ],
    [ "~PvGenBrowserWnd", "class_pv_gen_browser_wnd.html#a64cdfc34ea418c3089415d08c749bb1d", null ],
    [ "GetVisibility", "class_pv_gen_browser_wnd.html#a86db1989104f1f154a898619a461fcca", null ],
    [ "IsParameterDisplayed", "class_pv_gen_browser_wnd.html#a61e5279ec09f21e9e994ef40764870d7", null ],
    [ "Load", "class_pv_gen_browser_wnd.html#af8452cb76a3e262bee37565f37eab200", null ],
    [ "Refresh", "class_pv_gen_browser_wnd.html#add548fd91535eb3d57c765d5cba8ae9c", null ],
    [ "Save", "class_pv_gen_browser_wnd.html#a551d905c93316443a6a8cf0df266705b", null ],
    [ "SetGenParameterArray", "class_pv_gen_browser_wnd.html#abb8172f642c18d61fbeb39484a14537c", null ],
    [ "SetVisibility", "class_pv_gen_browser_wnd.html#a068c32eb050effecc4aaf693623898dd", null ]
];