var class_pv_device_s_p_i_bus =
[
    [ "PvDeviceSPIBus", "class_pv_device_s_p_i_bus.html#a3f4b3e5fffa20f3d9e2da5caccaf2f24", null ],
    [ "~PvDeviceSPIBus", "class_pv_device_s_p_i_bus.html#a044b861e666d5762bcc9d742da230a41", null ],
    [ "BurstRead", "class_pv_device_s_p_i_bus.html#a0a2e6647ab23d60ce23c23824ee7aa8c", null ],
    [ "BurstWriteAndRead", "class_pv_device_s_p_i_bus.html#a6d2da48f8c71e135432b09618df00a5d", null ],
    [ "Close", "class_pv_device_s_p_i_bus.html#a362747beddd2fa40e31e16a027ca01e8", null ],
    [ "IsOpened", "class_pv_device_s_p_i_bus.html#acbaf5ba7777ffbaf9b5a48658fec396f", null ],
    [ "Open", "class_pv_device_s_p_i_bus.html#a9409b30b42eee3a5ada64fd35104ee36", null ]
];