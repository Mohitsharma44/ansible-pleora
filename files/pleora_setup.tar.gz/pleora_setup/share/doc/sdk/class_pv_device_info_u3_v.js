var class_pv_device_info_u3_v =
[
    [ "~PvDeviceInfoU3V", "class_pv_device_info_u3_v.html#a16243c0cd01e9deb639f3c39a7cd664c", null ],
    [ "PvDeviceInfoU3V", "class_pv_device_info_u3_v.html#a0fad310fc731972f3658667d90733da8", null ],
    [ "GetDeviceGUID", "class_pv_device_info_u3_v.html#aa6b3eadc94422a480c9547cb37bf6a95", null ],
    [ "GetFamilyName", "class_pv_device_info_u3_v.html#a137a94ff668c066bd942cb280db2805b", null ],
    [ "GetGenCPVersion", "class_pv_device_info_u3_v.html#a97c48043ebe2acceda9170a9753e40ef", null ],
    [ "GetMaxPower", "class_pv_device_info_u3_v.html#a10add24fc5a8d452ebdbac5cad91554d", null ],
    [ "GetSpeed", "class_pv_device_info_u3_v.html#a80d8f0fb0d1811f28dc739e4ea98e40b", null ],
    [ "GetU3VSerialNumber", "class_pv_device_info_u3_v.html#ad81e89cec329e69c66d8b5779306e953", null ],
    [ "GetU3VVersion", "class_pv_device_info_u3_v.html#a133611bd3763f71728e86ddffdf8c9ef", null ],
    [ "IsFullSpeedSupported", "class_pv_device_info_u3_v.html#ae1f3e108ee8a35a356856119f39c5321", null ],
    [ "IsHighSpeedSupported", "class_pv_device_info_u3_v.html#a0f26837f5fbb391c6eb2390267b2ba62", null ],
    [ "IsLowSpeedSupported", "class_pv_device_info_u3_v.html#a939e5caeaf8103043c638e69a94a9c8e", null ],
    [ "IsPleoraDriverInstalled", "class_pv_device_info_u3_v.html#a689f4010e8ad90b7d0d606fbc53f83f9", null ],
    [ "IsSuperSpeedSupported", "class_pv_device_info_u3_v.html#a9e89590afcc5171b17de897dc7e00d69", null ]
];