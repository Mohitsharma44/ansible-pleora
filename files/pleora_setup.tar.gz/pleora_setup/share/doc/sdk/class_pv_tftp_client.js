var class_pv_tftp_client =
[
    [ "PvTftpClient", "class_pv_tftp_client.html#ae24bc83ce095fc2f47fa80862220f458", null ],
    [ "~PvTftpClient", "class_pv_tftp_client.html#ad8bc2ffbf5d4e275c0d6b768e5271c6f", null ],
    [ "Abort", "class_pv_tftp_client.html#ae7301c6cc695fb1e654e86ef3b2b0ec1", null ],
    [ "GetData", "class_pv_tftp_client.html#a8406e9ed9a706f3efae39f1275492960", null ],
    [ "GetFile", "class_pv_tftp_client.html#ade736e6565db66f024b6e18c4eb77621", null ],
    [ "GetProgress", "class_pv_tftp_client.html#a102011b95d2c4254ca546250d85061f9", null ],
    [ "GetTransferResult", "class_pv_tftp_client.html#a934e3883aa42f63558e9861ffae8d8e9", null ],
    [ "GetWarning", "class_pv_tftp_client.html#a5d5dea02e65cac2f70ece470cd2fbcdb", null ],
    [ "Init", "class_pv_tftp_client.html#ace01e50b4e7080c2e2fa185677c85ab0", null ],
    [ "SendData", "class_pv_tftp_client.html#a40a67bf9c2d78e22b6c56b147cf4900e", null ],
    [ "SendFile", "class_pv_tftp_client.html#aa1e072d841a7a141ad742c867f4dbbeb", null ]
];