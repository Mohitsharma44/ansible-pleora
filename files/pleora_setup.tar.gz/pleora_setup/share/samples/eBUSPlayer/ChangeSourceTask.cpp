// *****************************************************************************
//
//     Copyright (c) 2013, Pleora Technologies Inc., All rights reserved.
//
// *****************************************************************************

#include "eBUSPlayerShared.h"
#include "ChangeSourceTask.h"


#ifdef _AFXDLL
    IMPLEMENT_DYNAMIC( ChangeSourceTask, Task )
#endif // _AFXDLL


