// *****************************************************************************
//
//     Copyright (c) 2013, Pleora Technologies Inc., All rights reserved.
//
// *****************************************************************************

#include "eBUSPlayerShared.h"
#include "LoadTask.h"


#ifdef _AFXDLL
    IMPLEMENT_DYNAMIC( LoadTask, Task )
#endif // _AFXDLL


