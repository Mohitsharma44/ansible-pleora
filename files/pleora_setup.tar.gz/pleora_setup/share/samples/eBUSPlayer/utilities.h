// *****************************************************************************
//
//     Copyright (c) 2013, Pleora Technologies Inc., All rights reserved.
//
// *****************************************************************************

#pragma once

#define PTMIN(a,b) (((a)<(b)) ? (a) : (b))
#define PTMAX(a,b) (((a)>(b)) ? (a) : (b))
